//package com.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCrypt;
//import org.springframework.stereotype.Service;
//
//import com.entity.UserEntity;
//@Service
//public class AuthService {
//	@Autowired
//	private UserService userService;
//	public Optional<UserEntity> loginUser(String email, String password){
//		Optional<UserEntity> user=userService.findbyEmail(email);
//		if(user.isPresent() && checkPassword(password,user.get().getPassword())) {
//			return user;
//		}
//		return Optional.empty();
//	}
//	public boolean checkPassword(String plainPassword, String hashedPassword) {
//		return BCrypt.checkpw(plainPassword, hashedPassword);
//	}
//}

package com.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.dao.UserDao;
import com.entity.UserEntity;

@Service
public class AuthService {
    @Autowired
    private UserDao userDao;

    public UserEntity loginUser(String email, String password) {
        Optional<UserEntity> userOptional = userDao.findByEmail(email);
        if (userOptional.isPresent()) {
            UserEntity user = userOptional.get();
            if (BCrypt.checkpw(password, user.getPassword())) {
                return user;
            } else {
                throw new RuntimeException("Invalid password");
            }
        } else {
            throw new RuntimeException("User not found");
        }
    }
}
