package com.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDao;
import com.entity.UserEntity;

@Service
public class UserService {

	    @Autowired
	    private UserDao userDao;
	    
	    public Optional<UserEntity> getUserById(Long userId) {
	        return userDao.findById(userId);
	    }

	    public UserEntity registerUser(UserEntity user) {
	        return userDao.save(user);
	    }
	}



