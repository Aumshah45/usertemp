//package com.controller;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.entity.UserEntity;
////import com.service.AuthService;
//import com.service.UserService;
//
//@RestController
//@RequestMapping("/users")
//public class UserController {
//	@Autowired
//	private UserService userService;
//	
////	@Autowired
////	private AuthService authService;
//	
////	@PostMapping("/register")
////	public ResponseEntity<UserEntity> registerUser(@RequestBody UserEntity user){
////		UserEntity registeredUser=userService.registerUser(user);
////		return new ResponseEntity<>(registeredUser,HttpStatus.CREATED);
////	}
//
////	@PostMapping("/login")
////	public ResponseEntity<UserEntity> loginUser(@RequestParam String email,@RequestParam String password){
////		Optional<UserEntity> user=authService.loginUser(email, password);
////		if(user.isPresent()) {
////			return new ResponseEntity<>(user.get(), HttpStatus.OK);
////		}
////		else {
////			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
////		}
////	}
////
////	@GetMapping("/{userId}")
////	public ResponseEntity<UserEntity> getUserbyId(@PathVariable Long userId){
////		Optional<UserEntity> user=userService.getUserbyId(userId);
////		return user.map(value-> new ResponseEntity<>(value, HttpStatus.OK))
////				.orElseGet(()->new ResponseEntity<>(HttpStatus.NOT_FOUND));
////	}
//	
//	@PostMapping("/register")
//	public UserEntity registerUser(@RequestBody UserEntity user) {
//		return userService.registerUser(user);
//	}
//}
package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.entity.UserEntity;
import com.service.UserService;
import com.service.AuthService;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public UserEntity registerUser(@RequestBody UserEntity user) {
        try {
            return userService.registerUser(user); // Register user
        } catch (RuntimeException e) {
           
            System.out.println("Registration failed: " + e.getMessage());
            return null;
        }
    }

    @PostMapping("/login")
    public UserEntity loginUser(@RequestParam String email, @RequestParam String password) {
        try {
            return authService.loginUser(email, password); // Authenticate user
        } catch (RuntimeException e) {
          
            System.out.println("Login failed: " + e.getMessage());
            return null; 
        }
    }
}
